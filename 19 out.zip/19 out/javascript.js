let resp = window.document.getElementById('saida')
function ação1(){
    resp.innerHTML += '<p>Clicou no primeiro botao'
}
function ação2(){
    resp.innerHTML += '<p>Clicou no segundo botao'
}
function ação3(){
    resp.innerHTML += '<p>Clicou no terceiro botao'
}
function ação4(){
    resp.innerHTML += '<p>Clicou no quarto botao'
}