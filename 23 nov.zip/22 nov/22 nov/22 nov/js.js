const trocarElemento = document.querySelector('.logo');

trocarElemento.addEventListener('mouseover',() => {
    trocarElemento.innerText = 'ESCOLHA SUA FRAGRÂNCIA';
});
trocarElemento.addElementLister('mouseout', () => {
    trocarElemento.innerText = 'oBoticário';
});