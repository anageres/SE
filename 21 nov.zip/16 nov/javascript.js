const trocarElemento = document.querySelector('.logo');

trocarElemento.addEventListener('mouseover',() => {
    trocarElemento.innerText = 'BITE';
});
trocarElemento.addElementLister('mouseout', () => {
    trocarElemento.innerText = 'ESCOLHA SUA FRAGRÂNCIA';
});