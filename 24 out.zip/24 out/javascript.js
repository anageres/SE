function calcular(){
    let num = Number (window.prompt('digite um número:'))
    let res = document.querySelector('section#result1')
    res.innerHTML = `<p> O número a ser analisado aqui será o <strong>${num}</strong></p>`

    res.innerHTML += `<p>O seu valor absoluto é <strong>${Math.abs(num)}</strong></p>`

    res.innerHTML += `<p> A sua parte inteira é <strong>${Math.trunc(num)}</strong><p>`

    res.innerHTML += `<p> O seu valor inteiro mais próximo é <strong>${Math.round(num)}</strong><p>`

    res.innerHTML += `<p> A sua raiz quadrada é <strong>${Math.sqrt(num)}</strong><p>`

    res.innerHTML += `<p> A sua raiz cubica é <strong>${Math.cbrt(num)}</strong><p>`

    res.innerHTML += `<p>O valor de ${num}<sup>2</sup> <strong>${Math.pow(num,2)}</strong></p>`

    res.innerHTML += `<p>O valor de ${num}<sup>3</sup> <strong>${Math.pow(num,3)}</strong></p>`
}

let contador = 0
let res = document.querySelector('section#result2')


function contar(){
    contador++
    res.innerHTML = `<p> O contador está em <strong>${contador}</strong> Cliques<p>`
}


function zerar(){
    contador = 0
    res.innerHTML = null
}

function calculo(){
    let a = Number(document.getElementById('a').value);
    let b = Number(document.getElementById('b').value);
    let c = Number(document.getElementById('c').value);

    document.querySelector('#result3').innerHTML =
    `a soma de <mark> ${a} + ${b} </mark> divido por <strong> 
    ${c}</strong> é igual a:<strong> ${(a + b) / c}</strong>`

}



    
